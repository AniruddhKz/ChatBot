package com.aniruddha;

import java.util.Scanner;

public class SimpleChatbot {

	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in);
		System.out.println("hello ");
		String name;
		String.name=scan.nextLine();
		System.out.println(" "+name);
		while(true) {
			String input=scan.nextLine(); 
			if(input.contains(" ")|| input.contains(" ")) {
				System.out.println(" hi there ");
			}
			
			else if(input.contains("no")) {
				System.out.println("program ");
			}
			else if(input.contains("Hz")) {
				System.out.println(" program 100 ");
			}
			else {
				System.out.println("program 200 ");
			}
		}
		scan.close();
		 

	}

	private static void toLowerCase() {
		// TODO Auto-generated method stub
		
	}

}
